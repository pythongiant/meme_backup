from django.contrib import admin
from .models import Gif
# Register your models here.
admin.site.register(Gif)
