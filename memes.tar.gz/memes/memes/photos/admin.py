from django.contrib import admin
from .models import Memes,Comment
# Register your models here.
admin.site.register(Memes)
admin.site.register(Comment)